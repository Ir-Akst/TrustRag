#table(
  columns: {{ (head[0] if head else body[0] if body else []) | length or 1 }},
{% for r in head %}
  {% for c in r %}[{% if c["is_visible"] %}{{ c["display_value"] }}{% endif %}],{% if not loop.last %} {% endif%}{% endfor %}

{% endfor %}

{% for r in body %}
  {% for c in r %}[{% if c["is_visible"] %}{{ c["display_value"] }}{% endif %}],{% if not loop.last %} {% endif%}{% endfor %}

{% endfor %}
)
